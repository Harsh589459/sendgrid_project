module.exports = [
  "harsh.singh@clevertap.com",
  "hs589459@gmail.com",
  "tamanna@clevertap.com",
  "mohammed.khan@clevertap.com",
  "anmol.sawhney@clevertap.com",
  "mashnu@clevertap.com"
]