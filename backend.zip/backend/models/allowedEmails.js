module.exports = [
  "harsh.singh@clevertap.com",
  "hs589459@gmail.com"
 
]
